from sqlalchemy import Column, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.dialects.sqlite import JSON as SQLiteJSON
from sqlalchemy.orm import relationship
from .database import Base
import uuid, datetime

def gen_id():
    return str(uuid.uuid4())

class Study(Base):
    __tablename__ = "studies"
    id = Column(String, primary_key=True, default=gen_id)
    modality = Column(String, nullable=False)
    region = Column(String, nullable=False)
    side = Column(String, nullable=True)
    contrast = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class Report(Base):
    __tablename__ = "reports"
    id = Column(String, primary_key=True, default=gen_id)
    study_id = Column(String, ForeignKey("studies.id"))
    findings_json = Column(SQLiteJSON)
    impression = Column(Text)
    status = Column(String, default="draft")
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    study = relationship("Study")
