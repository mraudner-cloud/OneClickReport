# Rule-based generator (placeholder for real LLM)
from typing import List, Optional
from ..schemas import Finding, StudyCreate

def cautious_negative(sentence: str) -> str:
    return sentence.rstrip(".") + "."

def generate_findings_text(study: StudyCreate, findings: List[Finding]) -> str:
    lines = []
    # Abnormalities first
    for f in findings:
        base = f.label
        if f.severity:
            base = f"{f.severity.capitalize()} {base}"
        if f.comment:
            base += f". {f.comment}"
        if not base.endswith("."):
            base += "."
        lines.append(base)
    # Then restrained normals per region
    region = study.region.lower()
    if region in ["knee", "right knee", "left knee"]:
        lines += [
            "ACL and PCL are intact with no convincing evidence of tear.",
            "Collateral ligaments appear preserved without significant abnormality.",
            "No suspicious osteochondral lesion is identified.",
            "No suspicious lymphadenopathy."
        ]
    elif "lumbar" in region:
        lines += [
            "Physiological alignment without convincing spondylolisthesis.",
            "Conus medullaris appears regular.",
            "No suspicious marrow replacing lesion.",
        ]
    elif region in ["thorax", "chest"]:
        lines += [
            "No focal consolidation of significance.",
            "No significant abnormality of the great thoracic vessels.",
            "No suspicious lymphadenopathy."
        ]
    elif region in ["abdomen"]:
        lines += [
            "No suspicious lymphadenopathy.",
            "No convincing focal liver lesion of clinical significance.",
        ]

    elif region in ["head", "skull"]:
        lines += [
            "No convincing acute intracranial haemorrhage.",
            "Grey–white differentiation appears preserved.",
            "Basal cisterns remain patent."
        ]
    elif region in ["neck"]:
        lines += [
            "No suspicious cervical lymphadenopathy.",
            "No convincing retropharyngeal fluid collection."
        ]
    elif region in ["shoulder"]:
        lines += [
            "Rotator cuff tendons appear continuous without full-thickness tear.",
            "No convincing joint effusion."
        ]
    elif region in ["ankle"]:
        lines += [
            "No convincing osteochondral lesion of clinical significance.",
            "Tendons about the ankle joint appear intact."
        ]
    else:
        lines.append("No suspicious abnormality elsewhere within the field of view.")
    # Deduplicate while preserving order
    seen=set(); unique=[]
    for l in lines:
        if l not in seen:
            seen.add(l); unique.append(l)
    return "\n".join(unique)

def generate_impression(findings: List[Finding]) -> str:
    # Simple priority: severe -> moderate -> mild -> unspecified
    order = {"severe":0, "moderate":1, "mild":2, None:3}
    sorted_items = sorted(findings, key=lambda f: order.get(f.severity, 3))
    lines=[]
    for idx, f in enumerate(sorted_items, start=1):
        label = f.label[0].upper() + f.label[1:]
        if f.severity:
            label = f"{label} – {f.severity}"
        lines.append(f"{idx}. {label}")
    if not lines:
        lines = ["1. No actionable abnormality detected."]
    lines.append("Correlation with clinical findings is recommended.")
    return "\n".join(lines)
