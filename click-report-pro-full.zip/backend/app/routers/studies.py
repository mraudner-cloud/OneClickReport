from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..database import SessionLocal, Base, engine
from ..models import Study
from ..schemas import StudyCreate, StudyOut

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

Base.metadata.create_all(bind=engine)

@router.post("", response_model=StudyOut)
def create_study(payload: StudyCreate, db: Session = Depends(get_db)):
    s = Study(modality=payload.modality, region=payload.region, side=payload.side, contrast=payload.contrast)
    db.add(s); db.commit(); db.refresh(s)
    return s
