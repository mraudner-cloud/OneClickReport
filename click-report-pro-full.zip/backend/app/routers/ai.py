from fastapi import APIRouter
from ..schemas import TranscriptionRequest, TranscriptionResponse, GenerateRequest, GenerateResponse
from .utils import clean_text, plausibility_notes
from ..services.ai_engine import generate_findings_text, generate_impression

router = APIRouter()

@router.post("/transcribe", response_model=TranscriptionResponse)
def transcribe(req: TranscriptionRequest):
    cleaned = clean_text(req.dictation_text)
    notes = plausibility_notes(cleaned)
    return TranscriptionResponse(transcription=cleaned, notes=notes or None)

@router.post("/generate", response_model=GenerateResponse)
def generate(req: GenerateRequest):
    # Transcription stage (text already provided as structured input here)
    transcription = clean_text("\n".join([f.label for f in req.findings]))
    # Report stage
    findings_text = generate_findings_text(req.study, req.findings)
    impression_text = generate_impression(req.findings)
    report = f"""REPORT:
STUDY: {req.study.modality} {req.study.region}
CLINICAL DETAILS: {req.clinical_details or "[Clarify]"}
TECHNIQUE: {req.technique or "Standard protocol."}
FINDINGS:
{findings_text}

IMPRESSION:
{impression_text}
"""
    return GenerateResponse(transcription=transcription, report_text=report)
