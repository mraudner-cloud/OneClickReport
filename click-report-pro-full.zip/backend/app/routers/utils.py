import re
from typing import List

def clean_text(s: str) -> str:
    s = s.strip()
    # Normalise whitespace and punctuation spacing
    s = re.sub(r'\s+', ' ', s)
    s = re.sub(r'\s*([.,;:])\s*', r'\1 ', s)
    s = re.sub(r'\s+$', '', s)
    # Capitalise sentence starts (basic)
    sentences = re.split(r'(?<=[.!?])\s+', s)
    sentences = [sent[:1].upper() + sent[1:] if sent else '' for sent in sentences]
    return "\n".join([t.strip() for t in sentences if t.strip()])

def plausibility_notes(cleaned: str) -> List[str]:
    notes = []
    if any(word in cleaned.lower() for word in ["left", "right"]) and "bilateral" in cleaned.lower():
        notes.append("[Inconsistent] Mentions left/right and bilateral.")
    if "?" in cleaned:
        notes.append("[Clarify] Questioned statements present.")
    return notes
