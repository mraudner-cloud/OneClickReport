from fastapi import APIRouter
from ..schemas import GenerateRequest
from ..routers.ai import generate as ai_generate

router = APIRouter()

@router.post("/draft")
def draft_report(req: GenerateRequest):
    return ai_generate(req)
