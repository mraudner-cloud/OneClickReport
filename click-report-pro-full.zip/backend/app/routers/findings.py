from typing import List, Dict

# Extended taxonomy covering CT (head/neck/thorax/abdomen) and MRI spine/shoulder/knee/ankle
TAXONOMY = [
    # --- CT HEAD / SKULL ---
    {"id": "ct-head-ich",  "label": "Acute intracranial haemorrhage", "region": "head"},
    {"id": "ct-head-infarct", "label": "Territorial ischaemic infarct", "region": "head"},

    # --- CT NECK ---
    {"id": "ct-neck-abscess", "label": "Retropharyngeal abscess", "region": "neck"},
    {"id": "ct-neck-lymphnodes", "label": "Suspicious cervical lymphadenopathy", "region": "neck"},

    # --- CT THORAX ---
    {"id": "ct-thorax-pneumonia", "label": "Lobar pneumonia", "region": "thorax"},
    {"id": "ct-thorax-emboli", "label": "Pulmonary embolism", "region": "thorax"},
    {"id": "ct-thorax-aneurysm", "label": "Ascending aortic aneurysm", "region": "thorax"},

    # --- CT ABDOMEN / PELVIS ---
    {"id": "ct-abdomen-appendicitis", "label": "Acute appendicitis", "region": "abdomen"},
    {"id": "ct-abdomen-liver-met", "label": "Suspicious hepatic metastasis", "region": "abdomen"},
    {"id": "ct-abdomen-diverticulitis", "label": "Sigmoid diverticulitis", "region": "abdomen"},

    # --- MRI CERVICAL / THORACIC / LUMBAR SPINE ---
    {"id": "mri-csp-disc", "label": "C5/6 disc extrusion", "region": "cervical spine"},
    {"id": "mri-csp-myelopathy", "label": "Cervical cord T2 hyperintensity", "region": "cervical spine"},
    {"id": "mri-tsp-fracture", "label": "T7 compression fracture", "region": "thoracic spine"},
    {"id": "mri-lsp-stenosis", "label": "L4/5 central canal stenosis", "region": "lumbar spine"},

    # --- MRI SHOULDER ---
    {"id": "mri-shoulder-supra-tear", "label": "Full-thickness supraspinatus tear", "region": "shoulder"},
    {"id": "mri-shoulder-slap", "label": "Type II SLAP lesion", "region": "shoulder"},

    # --- MRI KNEE ---
    {"id": "mri-knee-acl", "label": "Anterior cruciate ligament rupture", "region": "knee"},
    {"id": "mri-knee-meniscus-med", "label": "Medial meniscal tear", "region": "knee"},
    {"id": "mri-knee-chondropathy", "label": "Patellar chondropathy grade III–IV", "region": "knee"},

    # --- MRI ANKLE ---
    {"id": "mri-ankle-osteochon", "label": "Osteochondral lesion of talar dome", "region": "ankle"},
    {"id": "mri-ankle-achilles", "label": "Achilles tendon rupture", "region": "ankle"}
]


def get_region(t):
    return t.get("region","").lower()

# --- API -------------------------------------------------
from fastapi import APIRouter, Query
router = APIRouter()

@router.get("/taxonomy")
def get_taxonomy(region: str = Query(None, description="Filter by region")) -> List[Dict]:
    if region:
        return [t for t in TAXONOMY if get_region(t) == region.lower()]
    return TAXONOMY
