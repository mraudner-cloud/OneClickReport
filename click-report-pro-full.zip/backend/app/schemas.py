from pydantic import BaseModel, Field
from typing import Optional, List, Literal, Any

class StudyCreate(BaseModel):
    modality: str
    region: str
    side: Optional[str] = None
    contrast: Optional[bool] = False

class StudyOut(StudyCreate):
    id: str
    class Config:
        from_attributes = True

class Finding(BaseModel):
    radlex_code: Optional[str] = None
    label: str
    severity: Optional[Literal["mild", "moderate", "severe"]] = None
    comment: Optional[str] = None

class GenerateRequest(BaseModel):
    study: StudyCreate
    clinical_details: Optional[str] = None
    comparison: Optional[str] = None
    technique: Optional[str] = None
    findings: List[Finding]

class GenerateResponse(BaseModel):
    transcription: str
    report_text: str

class TranscriptionRequest(BaseModel):
    dictation_text: str

class TranscriptionResponse(BaseModel):
    transcription: str
    notes: Optional[List[str]] = None
