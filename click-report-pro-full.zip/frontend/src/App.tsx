import React, { useEffect, useState } from 'react'
import { StudyPicker } from './components/StudyPicker'
import { FindingsTree } from './components/FindingsTree'
import { PreviewPane } from './components/PreviewPane'
import { draftReport, getTaxonomy } from './services/api'

export default function App() {
  const [study, setStudy] = useState({ modality: 'MRI', region: 'knee', side: '', contrast: false })
  const [clinicalDetails, setClinicalDetails] = useState('')
  const [technique, setTechnique] = useState('Multiplanar sequences without contrast.')
  const [taxonomy, setTaxonomy] = useState<any[]>([])
  const [selected, setSelected] = useState<any[]>([])
  const [report, setReport] = useState('')
  const [transcription, setTranscription] = useState('')

  useEffect(() => {
    getTaxonomy(study.region).then(setTaxonomy)
  }, [study.region])

  async function generate() {
    const payload = {
      study,
      clinical_details: clinicalDetails,
      technique,
      findings: selected.map((s: any) => ({ label: s.label, severity: s.severity }))
    }
    const res = await draftReport(payload)
    setTranscription(res.transcription)
    setReport(res.report_text)
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, padding: 16, fontFamily: 'system-ui, sans-serif' }}>
      <div>
        <h2>Click-&-Report</h2>
        <StudyPicker value={study} onChange={setStudy} />
        <label>Clinical details</label>
        <textarea value={clinicalDetails} onChange={e=>setClinicalDetails(e.target.value)} style={{ width:'100%', height:60 }} />
        <label>Technique</label>
        <textarea value={technique} onChange={e=>setTechnique(e.target.value)} style={{ width:'100%', height:60 }} />
        <FindingsTree data={taxonomy} onSelect={(item:any)=>setSelected(prev=>[...prev, {...item, severity:'moderate'}])} />
        <button onClick={generate} style={{ marginTop: 12 }}>Generate</button>
        <h3>Transcription</h3>
        <pre style={{ background:'#f5f5f5', padding: 8 }}>{transcription}</pre>
      </div>
      <div>
        <PreviewPane text={report} />
      </div>
    </div>
  )
}
