export async function getTaxonomy(region?: string) {
  const q = region ? `?region=${encodeURIComponent(region)}` : ''
  const res = await fetch(`http://127.0.0.1:8000/findings/taxonomy${q}`)
  return res.json()
}

export async function draftReport(payload: any) {
  const res = await fetch(`http://127.0.0.1:8000/reports/draft`, {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  })
  return res.json()
}
