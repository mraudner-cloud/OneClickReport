import React from 'react'

export function FindingsTree({ data, onSelect }: any){
  return (
    <div style={{ marginTop: 12 }}>
      <h4>Findings library</h4>
      <ul>
        {data.map((d:any)=> (
          <li key={d.id} style={{ marginBottom: 6 }}>
            <button onClick={()=>onSelect(d)}>{d.label}</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
