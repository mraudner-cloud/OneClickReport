import React from 'react'

export function StudyPicker({ value, onChange }: any){
  return (
    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:8, margin:'12px 0' }}>
      <div>
        <label>Modality</label>
        <select value={value.modality} onChange={e=>onChange({...value, modality:e.target.value})}>
          <option>MRI</option>
          <option>CT</option>
          <option>XR</option>
          <option>US</option>
        </select>
      </div>
      <div>
        <label>Region</label>
        <select value={value.region} onChange={e=>onChange({...value, region:e.target.value})}>
          <option>head</option>
          <option>neck</option>
          <option>thorax</option>
          <option>abdomen</option>
          <option>cervical spine</option>
          <option>thoracic spine</option>
          <option>lumbar spine</option>
          <option>shoulder</option>
          <option>knee</option>
          <option>ankle</option>
        </select>
      </div>
      <div>
        <label>Side</label>
        <select value={value.side} onChange={e=>onChange({...value, side:e.target.value})}>
          <option value=""></option>
          <option>right</option>
          <option>left</option>
          <option>bilateral</option>
        </select>
      </div>
      <div>
        <label>Contrast</label>
        <input type="checkbox" checked={value.contrast} onChange={e=>onChange({...value, contrast:e.target.checked})} />
      </div>
    </div>
  )
}