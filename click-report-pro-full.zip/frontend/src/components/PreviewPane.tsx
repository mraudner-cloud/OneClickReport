import React from 'react'

export function PreviewPane({ text }: any){
  return (
    <div>
      <h3>Report Preview</h3>
      <textarea value={text} readOnly style={{ width:'100%', height:'80vh' }}/>
    </div>
  )
}
