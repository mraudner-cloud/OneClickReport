# Click-&-Report (Starter)

Minimal full‑stack starter for a radiology reporting web app (MVP).  
Stack: **FastAPI + SQLite** (backend) and **React + Vite + TypeScript** (frontend).

> This starter generates reports without calling external AI (rule‑based templating).
> Swap `app/services/ai_engine.py` with a real LLM call later.

## Quick Start

### 1) Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Backend runs on http://127.0.0.1:8000 (Swagger: /docs).

### 2) Frontend

```bash
cd frontend
npm i
npm run dev
```

Frontend runs on http://127.0.0.1:5173

### 3) Optional (Docker Compose)

```bash
docker compose up --build
```

## Features (MVP)
- Study picker (modality/region/side/contrast)
- Findings library (small demo taxonomy with severities)
- Auto‑preview (rule‑based generator with cautious normal statements)
- Impression builder (sortable chips)
- Download report as TXT

## Medico‑legal posture
- Cautious phrasing for normals (e.g., “No suspicious lymphadenopathy.”)
- Optional LIMITATIONS section
- “Correlation with clinical findings is recommended.” safety line
- Audit log stub

## Next steps
- Connect real ASR (Azure/Cobalt/Vosk) to /transcribe
- Replace rule‑engine with your approved LLM + prompt
- HL7/FHIR export; DICOMweb viewer (CornerstoneJS) integration
- Role‑based auth, SSO, Postgres
